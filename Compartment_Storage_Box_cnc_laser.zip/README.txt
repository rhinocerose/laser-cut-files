                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1801392
Compartment Storage Box cnc/laser by ZenziWerken is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

I needed a compartment storage box for my screw assortment. So I designed this box with different sized compartments. I added tappets with corresponding recess to make the box stackable. As all the parts have pegs, the whole design just relies on press-fitting – no screws, no glue.

My build was done from a sheet of 4 mm high density fiber using a desktop cnc-machine by [Stepcraft](https://www.zenziwerken.de/my-cnc). I used material from the back plane of a closet I reclaimed from the trash. The surface is coated with shiny yellow, which looks really nice.

Visit https://www.zenziwerken.de/en/ for more interesting designs. Consider a donation if you like the build.

You can find another version with lid [here](http://www.thingiverse.com/thing:1801392).

The stl was uploaded just for a three dimensional display here on Thingiverse. If you want to print this – assuming you printer has a bed larger then 328 mm x 138 mm – you should extrude the dxf to the width of 4.15 mm.