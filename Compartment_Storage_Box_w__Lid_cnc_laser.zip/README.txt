                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1803499
Compartment Storage Box w/ Lid cnc/laser by ZenziWerken is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

After making the [compartment storage box](http://www.thingiverse.com/thing:1801392), my girls asked for another one to be used for sorting their iron beads. It should have a lid to prevent spilling the contents and making a hilarious mess. So I added a cnc-cut hinge and a snap latch.

My build was done from a sheet of 4 mm high density fiber using a desktop cnc-machine by [Stepcraft](https://www.zenziwerken.de/my-cnc). I used material from the back plane of a closet I reclaimed from the trash. The surface is coated with shiny yellow, which looks really nice.

Visit https://www.zenziwerken.de/en/ for more interesting designs. Consider a donation if you like the build.

Keep in mind that the stl was uploaded just for a three dimensional display here on Thingiverse.