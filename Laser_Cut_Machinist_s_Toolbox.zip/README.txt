                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2768972
Laser Cut Machinist's Toolbox by DrJekyll2k is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

You can find a full writeup at [instructables](https://www.instructables.com/id/Laser-Cut-Machinist-Toolbox/)

This is a lockable machinist's toolbox I built last year.  It is constructed entirely from 1/4 inch baltic birch.  The hardware was purchased from Rockler.  The exterior was finished with 4 coats of polyurethane varnish while the inside was left unfinished.  I lined the inside with laser cut foam to cushion the tools.  The toolbox has worked very well so far, surviving regular trips between my apartment and our makerspace.  You can find a quick video showing how the front panel works here https://youtu.be/wgjU_0VMBQE 
  
The drawers lock into the frame so that you cannot accidentally pull them out and spill your tools.  The drawer locking mechanisms are just screwed onto the back of each drawer and then rotated into place.  You can see an example in the attached video.  https://youtu.be/HAA-dLD_6Is


# Settings

150W laser cutter, 80% power at 10mm/s

<iframe src="//www.youtube.com/embed/HAA-dLD_6Is" frameborder="0" allowfullscreen></iframe>

# Video Overview

<iframe src="//www.youtube.com/embed/wgjU_0VMBQE" frameborder="0" allowfullscreen></iframe>