Product: Roller Derby Gear Rack, version 1.3, May 2015

Designer: Scott Austin, scotta@obrary.com

Support:  http://forums.obrary.com/category/designs/roller-derby-gear-rack 

Distributed by:  Obrary, Inc.  http://obrary.com
Obrary - making it easy to make

Description:
The Roller Derby Gear Rack is designed to be printed on a CNC router.  A 1/4" end mill bit should be used on 1/2" plywood.

Version 1.1 uses nails
Version 1.3 uses machine screws to assemble the rack.  This means the rack can also be unassembled.  